import urllib.parse

from flask import Flask, request, jsonify
from openai import OpenAI
import os


app = Flask(__name__)
session_contexts = {}

@app.route('/hello', methods=['GET'])
def get_stock_data():
    return 'hello hello'  # Return the complete stock_info dictionary


# run with:   curl -X POST http://localhost:5000/chat -H "Content-Type: application/json" -d '{"text": "Hello, how are you?"}'
@app.route('/chat', methods=['POST'])
def chat():
    try:
    # Extract text from the incoming JSON request
        data = request.json
        user_input = data.get('text')
        user_id = data.get('user_id', 'default_user')  # You should pass a unique user_id with each request

        # Retrieve the existing conversation context if it exists
        conversation_history = session_contexts.get(user_id, [])

        # OPENAI_API_KEY=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
        client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

        print('sending req to gpt ', conversation_history)
        # Call OpenAI GPT-3.5-turbo API using the updated API
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",  # Specify the GPT-3.5-turbo model
            messages=[{"role": "system", "content": "You are a helpful assistant."},
                      {"role": "user", "content": user_input}]
        )
        print('got response from gpt')
        # Extract the response text
        response_text = response.choices[0].message.content  # Accessing the 'content' attribute directly

        # Return the response text as JSON
        return jsonify({'response': response_text})
    except Exception as e:
        print("Error during API call:", e)
        return str(e)  # or handle the error appropriately

if __name__ == '__main__':
    app.run(debug=True)

